# Nested Hyperbolic Graph Convolutional Network
The codes are based on [HGCN](https://github.com/HazyResearch/hgcn) and [fully-hyperbolic-nn](https://github.com/chenweize1998/fully-hyperbolic-nn). 


## Dependencies

[Geotorch](https://github.com/Lezcano/geotorch) 

[PyTorch](https://pytorch.org/)

numpy

scikit-learn

networkx

##  Usage
 The data is avaliable in [HGCN](https://github.com/HazyResearch/hgcn). To run the experiments, download the datasets and put them in the `data` directory.
 
 ### ```train.py```

This script trains models with the following arguments

`--task` which task to trian on. Can be any of [lp, nc], lp denotes link prediction, and nc denotes node classification

`--dataset` which dataset to train on. Can be any of [airport, disease, cora, pubmed]

`--lr` learning rate

`--dim` dimension of the embeddings

`--num-layers` number of hidden layers

`--weight-decay` weight decay value.


The full list of arguments is in `config.py`.


## Examples


```python train.py --task nc --dataset disease_nc --model LorentzNet --dim 16 --num-layers 3 --bias 1 --normalize-feats 0 --manifold Lorentz --log-freq 5 --lr 0.01 --weight-decay 0.001 --margin 2 --dropout 0.1 --grad-clip 0.5 --cuda 0 --patience 2000 --seed 123 --lr-reduce-freq 1000``` 
