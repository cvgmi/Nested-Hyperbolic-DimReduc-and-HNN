from geomstats.learning.frechet_mean import FrechetMean, variance

def FM(man,X):
    #geomstates manifold
    estimator = FrechetMean(metric=man.metric, method='default', lr=1.)
    estimator.fit(X)
    return estimator.estimate_

def var(man,X):
    fm = FM(man,X)
    result = variance(points = X, base_point=fm, metric=man.metric)
    return result

def projection_error(man, X, X_hat):
    if X.dim == 1:
        error = man.metric.squared_dist(X, X_hat)
    else:
        N = X.shape[0]  # N*n
        error = 0
        for i in range(N):
            error = error + man.metric.squared_dist(X[i],X_hat[i])/N
    return error