"""Data utils."""

import numpy as np


def load_embeddings(dataset, dim):
    embeddings_path = f"data/embeddings/{dataset}_{dim}_poincare.npy"
    return np.load(embeddings_path)


