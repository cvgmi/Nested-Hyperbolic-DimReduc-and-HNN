"""Data utils."""

import numpy as np


def load_embeddings(dataset, dim):
    embeddings_path = f"data/embeddings/{dataset}_{dim}_poincare.npy"
    return np.load(embeddings_path)

def load_precomputed_projection(dataset,method, reduced_dim):
    projection_path = f"data/{method}/{method}_{dataset}_{reduced_dim}_projection.npy"
    return np.load(projection_path)
