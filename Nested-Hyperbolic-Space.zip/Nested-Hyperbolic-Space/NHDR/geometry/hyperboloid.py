"""Util functions for hyperboloid models
Convention: The ambient Minkowski space has signature -1, 1, 1, ...
                i.e. the squared norm of (t,x,y,z) is -t^2 + x^2 + y^2 + z^2,
            And we are using the positive sheet, i.e. every point on the hyperboloid
            has positive first coordinate.
"""
from matplotlib.pyplot import xcorr
import torch

#import geom.minkowski as minkowski
#import geometry.poincare as poincare

MIN_NORM = 1e-15

def inner_product(x, y):
    """
    -x0y0+x1y1+...+xnyn
    Args:
        x, y: torch.tensor of the same shape (..., Minkowski_dim)
    Returns:
        torch.tensor of shape (..., )
    """
    eucl_pairing = torch.sum(x * y, dim=-1, keepdim=False)
    return eucl_pairing - 2 * x[..., 0] * y[..., 0]

def check_belongs(x):
    innerdot = inner_product(x, x)
    check_belongs = torch.isclose(innerdot,-torch.ones_like(innerdot))
    return check_belongs


def dist(x, y):
    """
    Args:
        x, y: torch.tensor of the same shape (..., Minkowski_dim)
    Returns:
        torch.tensor of shape (..., )
    """
    return torch.acosh(torch.clamp(- inner_product(x, y), min=1.0))

def pairwise_distance(x):
    """All pairs of hyperbolic distances (NxN matrix)."""
    return dist(x.unsqueeze(-2), x.unsqueeze(-3))

def norm(x):
    squared_norm = inner_product(x, x)
    real_norm = torch.sqrt(torch.abs(squared_norm))
    return real_norm

def regularize(x):
    x_norm = torch.clamp(norm(x), min=1e-8)
    # if not torch.count_nonzero(x_norm) == x.shape[0]:
    #     raise ValueError(
    #         "Cannot project a vector of norm 0. in the "
    #         "Minkowski space to the hyperboloid")
    projected_x = torch.einsum("...i,...->...i", x, 1.0 / x_norm)
    return projected_x


def projection(x, dim: int = -1):
    dn = x.size(dim) - 1
    left_ = torch.sqrt(1 + torch.norm(x.narrow(dim, 1, dn), p=2, dim=dim) ** 2).unsqueeze(dim)
    right_ = x.narrow(dim, 1, dn)
    projected_x = torch.cat((left_, right_), dim=dim)
    return projected_x


def from_poincare(x):
    """Convert from Poincare ball model to hyperboloid model
    Args:
        x: torch.tensor of shape (..., dim)
        ideal: boolean. Should be True if the input vectors are ideal points, False otherwise
    Returns:
        torch.tensor of shape (..., dim+1)
    To do:
        Add some capping to make things numerically stable. This is only needed in the case ideal == False
    """

    eucl_squared_norm = (x * x).sum(dim=-1, keepdim=True)
    return torch.cat((1 + eucl_squared_norm, 2 * x), dim=-1) / (1 - eucl_squared_norm).clamp_min(MIN_NORM)

def to_poincare(x):
    """Convert from hyperboloid model to Poincare ball model
    Args:
        x: torch.tensor of shape (..., Minkowski_dim), where Minkowski_dim >= 3
        ideal: boolean. Should be True if the input vectors are ideal points, False otherwise
    Returns:
        torch.tensor of shape (..., Minkowski_dim - 1)
    """
    return x[..., 1:] / (1 + x[..., 0].unsqueeze(-1)).clamp_min(MIN_NORM)

def test():
    x = torch.tensor([[1.0, 0., 0.],[3.0, 2., 2.]])
    y = torch.tensor([[3.0, 2., 2.],[10.,0.,0.]])
    print(inner_product(x,x))
    print(inner_product(x,y))
    print(check_belongs(x))
    print(check_belongs(y))
    print(dist(x,x))
    print(dist(x,y))
    print(pairwise_distance(x))
    print(norm(x))
    print(norm(y))
    print(regularize(x))
    print(regularize(y))
    print(projection(x))
    print(projection(y))
    print(to_poincare(x))
    print(to_poincare(y))
    a = torch.tensor([[ 0., 0.],[ 0.5, 0.5]])
    b = torch.tensor([[ 0., 0.],[ 0.5, 0.]])
    print(from_poincare(a))
    print(from_poincare(b))

# Sanity checks
if __name__ == "__main__":
    test()