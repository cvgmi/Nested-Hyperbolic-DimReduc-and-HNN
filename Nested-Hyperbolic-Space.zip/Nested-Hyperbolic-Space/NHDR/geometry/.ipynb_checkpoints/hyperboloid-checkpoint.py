"""Util functions for hyperboloid models
Convention: The ambient Minkowski space has signature -1, 1, 1, ...
                i.e. the squared norm of (t,x,y,z) is -t^2 + x^2 + y^2 + z^2,
            And we are using the positive sheet, i.e. every point on the hyperboloid
            has positive first coordinate.
"""
import torch

import geom.minkowski as minkowski
import geom.poincare as poincare

MIN_NORM = 1e-15


def distance(x, y):
    """
    Args:
        x, y: torch.tensor of the same shape (..., Minkowski_dim)
    Returns:
        torch.tensor of shape (..., )
    """
    # return torch.acosh(- minkowski.bilinear_pairing(x, y))
    return torch.acosh(torch.clamp(- minkowski.bilinear_pairing(x, y), min=1.0))

def exp_unit_tangents(base_points, unit_tangents, distances):
    """Batched exponential map using the given base points, unit tangent directions, and distances
    Args:
        base_points, unit_tangents: torch.tensor of shape (..., Minkowski_dim)
            Each unit_tangents[j..., :] must have (Minkowski) squared norm 1 and is orthogonal to base_points[j..., :]
        distances:      torch.tensor of shape (...) 
    Returns:
        torch.tensor of shape (..., Minkowski_dim)
    """
    distances = distances.unsqueeze(-1)
    return base_points * torch.cosh(distances) + unit_tangents * torch.sinh(distances)


# def exp(base_points, tangents):
#     """Batched exponential map using the given base points and tangent vectors
#
#     Args:
#         base_point, tangents: torch.tensor of shape (..., Minkowski_dim)
#             Each tangents[j..., :] must have squared norm > 0 and is orthogonal to base_points[j..., :]
#
#     Returns:
#         torch.tensor of shape (..., Minkowski_dim)
#     """
#     distances = torch.sqrt(minkowski.squared_norm(tangents))  # shape (...)
#     unit_tangets = tangents / distances.view(-1, 1)  # shape (..., Minkowski_dim)
#     return exp_unit_tangents(base_point, unit_tangents, distances)


def from_poincare(x, ideal=False):
    """Convert from Poincare ball model to hyperboloid model
    Args:
        x: torch.tensor of shape (..., dim)
        ideal: boolean. Should be True if the input vectors are ideal points, False otherwise
    Returns:
        torch.tensor of shape (..., dim+1)
    To do:
        Add some capping to make things numerically stable. This is only needed in the case ideal == False
    """
    if ideal:
        t = torch.ones(x.shape[:-1], device=x.device).unsqueeze(-1)
        return torch.cat((t, x), dim=-1)
    else:
        eucl_squared_norm = (x * x).sum(dim=-1, keepdim=True)
        return torch.cat((1 + eucl_squared_norm, 2 * x), dim=-1) / (1 - eucl_squared_norm).clamp_min(MIN_NORM)


def to_poincare(x, ideal=False):
    """Convert from hyperboloid model to Poincare ball model
    Args:
        x: torch.tensor of shape (..., Minkowski_dim), where Minkowski_dim >= 3
        ideal: boolean. Should be True if the input vectors are ideal points, False otherwise
    Returns:
        torch.tensor of shape (..., Minkowski_dim - 1)
    """
    if ideal:
        return x[..., 1:] / (x[..., 0].unsqueeze(-1)).clamp_min(MIN_NORM)
    else:
        return x[..., 1:] / (1 + x[..., 0].unsqueeze(-1)).clamp_min(MIN_NORM)


def decision_boundary_to_poincare(minkowski_normal_vec):
    """Convert the totally geodesic submanifold defined by the Minkowski normal vector to Poincare ball model
    (Here the Minkowski normal vector defines a linear subspace, which intersects the hyperboloid at our submanifold)
    Args:
        minkowski_normal_vec: torch.tensor of shape (Minkowski_dim, )
    Returns:
        center: torch.tensor of shape (Minkowski_dim -1, )
        radius: float
    Warning:
        minkowski_normal_vec must have positive squared norm
        minkowski_normal_vec[0] must be nonzero (otherwise the submanifold is a flat plane through the origin)
    """
    x = minkowski_normal_vec
    # poincare_origin = [1,0,0,0,...], # shape (Minkowski_dim, )
    poincare_origin = torch.zeros(minkowski_normal_vec.shape[0], device=minkowski_normal_vec.device)
    poincare_origin[0] = 1

    # shape (1, Minkowski_dim)
    poincare_origin_reflected = minkowski.reflection(minkowski_normal_vec, poincare_origin.unsqueeze(0))

    # shape (Minkowski_dim-1, )
    origin_reflected = to_poincare(poincare_origin_reflected).squeeze(0)
    center = poincare.reflection_center(origin_reflected)

    radius = torch.sqrt(torch.sum(center ** 2) - 1)

    return center, radius