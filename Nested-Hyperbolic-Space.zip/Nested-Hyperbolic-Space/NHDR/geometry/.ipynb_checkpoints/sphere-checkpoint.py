"""Sphere utils functions."""

import torch


MIN_NORM = 1e-15
EPS = {torch.float32: 1e-4, torch.float64: 1e-7}


def inner_product(x,y):
    inner = torch.sum(x * y, dim=-1,keepdim=True)
    return inner


def distance(x, y) :
    eucl_pairing = inner_product(x, y).clamp(min=-1 + EPS[x.dtype], max=1 - EPS[x.dtype])
    #inner = inner_product(x, y).clamp(min=-1 + EPS[x.dtype], max=1 - EPS[x.dtype])
    return torch.acos(eucl_pairing)

def projx(x) :
    return x / x.norm(dim=-1, keepdim=True)

def proju(x,u) :
    u = u - (x * u).sum(dim=-1, keepdim=True) * x
    return u

def logmap0(y):
    x = torch.zeros(y.shape[-1])
    x[-1] = 1.
    u = proju(x, y - x)
    dist = distance(x, y)
    cond = dist.gt(EPS[x.dtype])
    result = torch.where(
            cond, u * dist / u.norm(dim=-1, keepdim=True).clamp_min(EPS[x.dtype]), u)
    return result


def logmap(x,y):
    u = proju(x, y - x)
    dist = distance(x, y)
    cond = dist.gt(EPS[x.dtype])
    result = torch.where(
            cond, u * dist / u.norm(dim=-1, keepdim=True).clamp_min(EPS[x.dtype]), u)
    return result

def expmap0(u):
    x = torch.zeros(u.shape[-1])
    x[-1] = 1.
    u_norm = u.norm(dim=-1, keepdim=True).clamp(MIN_NORM)
    exp = x * torch.cos(u_norm) + u * torch.sin(u_norm) / u_norm
    retr = projx(x + u)
    cond = u_norm > EPS[u_norm.dtype]
    return torch.where(cond, exp, retr)
    
def expmap(x,u):
    u_norm = u.norm(dim=-1, keepdim=True).clamp(MIN_NORM)
    exp = x * torch.cos(u_norm) + u * torch.sin(u_norm) / u_norm
    retr = projx(x + u)
    cond = u_norm > EPS[u_norm.dtype]
    return torch.where(cond, exp, retr)
