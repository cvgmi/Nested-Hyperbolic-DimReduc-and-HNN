import torch
from geomstats.geometry.hyperboloid import Hyperboloid
from geomstats.geometry.poincare_ball import PoincareBall

from utils.metrics import  projection_error

from geometry.hyperboloid import regularize,projection, check_belongs, dist

import pymanopt
from pymanopt.manifolds import Euclidean,Product,SpecialOrthogonalGroup
from pymanopt.solvers import SteepestDescent, ConjugateGradient



def NestedHyperboloid(X, m, verbosity=0):
    """ 
    X: array of N points on H(n); N x n array
    aim to represent X by X_hat (N points on H(n)) 
    where X_hat_i = cosh(r)(\Lambda I_{1,m} \Lambda^T x_i)/norm(\Lambda I_{1,m} \Lambda^T x_i) + sinh(r) v, 
    minimizing the geodesic distance
    """
    N, n = X.shape  # N*n
    man = Product([SpecialOrthogonalGroup(n-1),SpecialOrthogonalGroup(n-1),Euclidean(1),Euclidean(1)]) # Homeomorphic to O(1)xO(n-1) x R(n-1)

    X_ = X.type(torch.DoubleTensor)    #torch.from_numpy(X)
    Im_ = torch.eye(m).type(torch.DoubleTensor)
    Im_[0,0]= -1.
    In_ = torch.eye(n).type(torch.DoubleTensor)
    In_[0,0] = -1.

    @pymanopt.function.PyTorch
    def cost(P,Q,alpha,c1):
        P1 = torch.zeros(n,n).type(torch.DoubleTensor)
        P1[0, 0] = 1.
        P1[-(n-1):,-(n-1):] = P
        Q1 = torch.zeros(n,n).type(torch.DoubleTensor)
        Q1[0, 0] = 1.
        Q1[-(n-1):,-(n-1):] = Q
        alpha1 = torch.eye(n).type(torch.DoubleTensor)
        alpha1[-1,0] = torch.sinh(alpha)
        alpha1[0,-1] = torch.sinh(alpha)
        alpha1[0,0] = torch.cosh(alpha)
        alpha1[-1,-1] = torch.cosh(alpha)
        D =  P1 @ alpha1 @ Q1
        A = D[:,0:m]
        b = D[:,-1]
        ImATIn = Im_ @ A.t() @In_ 
        d2 = torch.tensor([1e-4])
        for i in range(N):
            ImATInXi = torch.matmul(ImATIn, X_[i])
            ImATInXi = regularize(ImATInXi).type(torch.DoubleTensor)
            if not check_belongs(ImATInXi.type(torch.float)):
                ImATInXi = projection(ImATInXi)
            AImATInXi = torch.matmul(A,ImATInXi)
            X_proj0 = torch.cosh(c1) * AImATInXi + torch.sinh(c1)*b
            X_proj0 = regularize(X_proj0).type(torch.DoubleTensor)
            if not check_belongs(X_proj0.type(torch.float)):
                X_proj0 = projection(X_proj0)
            belongs = check_belongs(X_proj0.type(torch.float))
            if belongs:
                d2 = d2 + dist(X[i], X_proj0)**2/N
            else:
                d2 = d2
        return d2
    
    solver = SteepestDescent(mingradnorm=5e-2)
    problem = pymanopt.Problem(manifold=man, cost=cost, verbosity=verbosity)
    theta = solver.solve(problem)

    P = torch.from_numpy(theta[0])
    Q = torch.from_numpy(theta[1])
    alpha = torch.from_numpy(theta[2])
    c1 = torch.from_numpy(theta[3])
    Q1 = torch.zeros(n,n).type(torch.DoubleTensor)
    Q1[0,0] =1.
    Q1[-(n-1):,-(n-1):] = Q
    P1 = torch.zeros(n,n).type(torch.DoubleTensor)
    P1[0,0] =1.
    P1[-(n-1):,-(n-1):] = P
    alpha1 = torch.eye(n).type(torch.DoubleTensor)
    alpha1[-1,0] = torch.sinh(alpha)
    alpha1[0,-1] = torch.sinh(alpha)
    alpha1[0,0] = torch.cosh(alpha)
    alpha1[-1,-1] = torch.cosh(alpha)
    D =  P1 @ alpha1 @Q1

    A = D[:,0:m]
    b = D[:,-1]

    tmp  = Im_ @ A.t() @ In_
    X_low = (tmp @ X_.transpose(0,1)).transpose(0,1)
    X_low = regularize(X_low)
    X_low = projection(X_low)

    AImATInX = (A @ X_low.transpose(0,1)).transpose(0,1)
    X_proj = torch.cosh(c1)*AImATInX+torch.sinh(c1)*b
    X_proj = regularize(X_proj)
    X_proj = projection(X_proj)
    
    error = (dist(X_,X_proj)**2).mean()
    
    return  error, X_low,X_proj