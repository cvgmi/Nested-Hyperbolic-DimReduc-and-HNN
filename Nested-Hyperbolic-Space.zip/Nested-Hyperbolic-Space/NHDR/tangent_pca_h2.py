"""Perform tangent PCA at the mean on H2."""

import logging

import matplotlib.pyplot as plt
import numpy as np
import torch

import geomstats.visualization as visualization
from geomstats.geometry.hyperboloid import Hyperboloid
from geomstats.geometry.poincare_ball import PoincareBall
from geomstats.learning.frechet_mean import FrechetMean
from geomstats.learning.pca import TangentPCA
from scipy.sparse import data
from utils.metrics import projection_error


def main():
    """Perform tangent PCA at the mean on H2."""

    n_dim = 2

    # poincar_plane = PoincareBall(dim=n_dim)
    hyperbolic_plane = PoincareBall(dim=n_dim)

    # hyperbolic_plane = Hyperboloid( dim= n_dim)

    dataset ='mean0'
    # dataset = 'smalltree'
    # dataset = 'bio-diseasome'
    # dataset = 'unbalancedtree'
    # dataset = 'hyperbola_large'
    # dataset = 'hyperbola_large3'
    # dataset = 'cuttree'

    embeddings_path = f"data/embeddings/{dataset}_2_poincare.npy"
    poincare_data =  torch.from_numpy(np.load(embeddings_path))

    data = poincare_data

    # data = Hyperboloid.change_coordinates_system(poincare_data,'ball','extrinsic')
    # data = hyperbolic_plane.projection(data)
    # print(data.shape)

    mean = FrechetMean(metric=hyperbolic_plane.metric)
    mean.fit(data)

    mean_estimate = mean.estimate_
    #print(mean_estimate)

    loss=[]

    for i in range(n_dim-1):

        n_pc = i+1
        print(f"n_pc: {n_pc}")
        tpca = TangentPCA(metric=hyperbolic_plane.metric, n_components=n_pc)
        tpca = tpca.fit(data, base_point=mean_estimate)
        tangent_projected_data = tpca.transform(data)
        projected_mean = tpca.transform(mean_estimate)
        high_projection = tpca.inverse_transform(tangent_projected_data)

        # high_projection = Hyperboloid.change_coordinates_system(high_projection,'extrinsic','ball')
     
        error = projection_error(hyperbolic_plane,poincare_data,high_projection)
        print(f"Projection error: {error}")
        loss.append(error)

    
        low_hyperbolic_plane = PoincareBall(dim=n_pc)
        low_embeddings = low_hyperbolic_plane.metric.exp(tangent_projected_data,base_point=projected_mean)

        # np.save('data/tpca/tpca'+'_'+dataset+'_%d_embeddings.npy'%(n_pc),low_embeddings)
        # np.save('data/tpca/tpca'+'_'+dataset+'_%d_projection.npy'%(n_pc),high_projection)
    

    # geodesic_0 = hyperbolic_plane.metric.geodesic(
    #     initial_point=mean_estimate, initial_tangent_vec=tpca.components_[0]
    # )

    # geodesic_1 = hyperbolic_plane.metric.geodesic(
    #     initial_point=mean_estimate, initial_tangent_vec=tpca.components_[1]
    # )


    # n_steps = 100
    # t = np.linspace(-3, 3, n_steps)
    # geodesic_points_0 = geodesic_0(t)
    # np.save('data/tpca/tpca'+'_'+dataset+'_%d_geodesic.npy'%(n_pc),geodesic_points_0)
    # geodesic_points_1 = geodesic_1(t)
    # projected_point = geodesic_0(tangent_projected_data[:,0].numpy())



    # logging.info(
    #     "Coordinates of the Log of the first 5 data points at the mean, "
    #     "projected on the principal components:"
    # )
    # logging.info("\n{}".format(tangent_projected_data[:5]))

    # logging.info(
    #     "projected on the manifold:"
    # )
    # logging.info("\n{}".format(manifold_projected_data[:5]))

    # logging.info(
    #     "Geodesic line:"
    # )
    # logging.info("\n{}".format(geodesic_points_0))

    # logging.info(
    #     "Projected point:"
    # )
    # logging.info("\n{}".format(projected_point))

    # logging.info(
    #     "base point (FM):"
    # )
    # logging.info("\n{}".format(tpca.base_point_fit))

    # logging.info(
    #     "Explained variance and cumulative explained variance:"
    # )
    # logging.info("\n{}".format(tpca.explained_variance_))
    # logging.info("\n{}".format(np.cumsum(tpca.explained_variance_)))

    logging.info(
        "Explained variance ratio and cumulative explained variance ratio:"
    )
    logging.info("\n{}".format(tpca.explained_variance_ratio_))
    logging.info("\n{}".format(np.cumsum(tpca.explained_variance_ratio_)))

    logging.info(
        "Projection error:"
    )
    logging.info("\n{}".format(loss))


    # ax_var = fig.add_subplot(121)
    # xticks = np.arange(1, n_pc + 1, 1)
    # ax_var.xaxis.set_ticks(xticks)
    # ax_var.set_title("Explained variance")
    # ax_var.set_xlabel("Number of Principal Components")
    # ax_var.set_ylim((0, 1))
    # ax_var.plot(xticks, np.cumsum(tpca.explained_variance_ratio_))


    # fig = plt.figure(figsize=(10,10))
    # ax = fig.add_subplot()

    # visualization.plot(
    #     mean_estimate, ax, space="H2_poincare_disk", color="darkgreen", s=10
    # )
    # visualization.plot(geodesic_points_0, ax, space="H2_poincare_disk", linewidth=2)
    # visualization.plot(geodesic_points_1, ax, space="H2_poincare_disk", linewidth=2)
    # visualization.plot(data, ax, space="H2_poincare_disk", color="black", alpha=0.7)

    # plt.show()
    # plt.savefig(fname ="tpca_hyperbola_1" )


if __name__ == "__main__":
    main()
