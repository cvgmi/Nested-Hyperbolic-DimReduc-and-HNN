Nested Hyperbolic Space for Dimensionality Reduction
==================================================

## Usage

In `NHDR.py`, the function `NestedHyperboloid` takes an $(N, n+1)$ tensor $X$ which represent $N$ data points in $n$ dimensional Lorentz model $\mathbb{L}^n$ and an integer $m < n$ as inputs and projects the $N$ points to $m$ dimensional Lorentz model $\mathbb{L}^m$. 

The outputs are the projection errror, the projected points $X_{low}$ which is an $(N, m+1)$ tensor and the reconstructed points $X_{proj}$ which is  an $(N, n+1)$ tensor.

The mean zero example can be found in `example_mean0.ipynb`.

Run 

``` python tangent_pca_h2.py ```

to process tangent PCA on hyperboloid model. (Based on [Geomstats](https://github.com/geomstats/geomstats))

## Datasets

The dataset is in the `data/embeddings` folder. 


## Dependencies

[Pymanopt](https://github.com/pymanopt/pymanopt) 

[Geomstats](https://github.com/geomstats/geomstats)

[geoopt](https://github.com/geoopt/geoopt)

[PyTorch](https://pytorch.org/)


The implementation of Tangent PCA, HoroPCA and Exatc PGA are based on [Geomstats](https://github.com/geomstats/geomstats), [HoroPCA](https://github.com/HazyResearch/HoroPCA)
and [Exact-PGA](https://github.com/cvgmi/Exact-PGA). Some precomputed results using these method are included in the `data/{METHODS}` folder. 